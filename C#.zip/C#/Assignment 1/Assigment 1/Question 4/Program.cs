﻿//1 - Create a class called Employee which contains properties for the First Name, Last Name, Employee ID, Salary, Department. 
//2 - Add a constructor which takes all parameters
//3 - Add a PrintDetails method to which prints all data about the Employee object to the console.  
//4 - Create two Employee objects and print their details using this method.
//5 - Add a method PayRise which takes a % increase and changes the Salary
//6 - Add some code to give both employees a pay rise.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    class Program
    {//4 - Create two Employee objects and print their details using this method.
        static void Main(string[] args)
        {
            Employee e1 = new Employee();
            e1.FirstName = "Tom";
            e1.LastName = "Jones";
            e1.EmployeeId = "emp215";
            e1.Salary = 30000.00;
            e1.Department = "Sales";
            //e1.PayRiseTom = 30000 * 0.10 + 30000;

            Console.WriteLine($"Employee {e1.EmployeeId}\n{e1.FirstName}{e1.LastName}\nWorks in the {e1.Department} department on a basic salary of EUR {e1.Salary:F}");

            Employee e2 = new Employee();
            e2.FirstName = "Mary";
            e2.LastName = "Smith";
            e2.EmployeeId = "emp145";
            e2.Salary = 35000.00;
            e2.Department = "Finance";
            //e2.PayRiseTom = 35000 * 0.07 + 35000;

            Console.WriteLine($"\nEmployee {e2.EmployeeId}\n{e2.FirstName}{e2.LastName}\nWorks in the {e2.Department} department on a basic salary of EUR {e2.Salary:F}");

            //6 - Add some code to give both employees a pay rise.
            Employee e3 = new Employee();
            e3.FirstName = "Tom";
            e3.LastName = "Jones";
            e3.EmployeeId = "emp215";
            e3.Salary = 30000 * 0.10 + 30000;
            e3.Department = "Sales";
            //e1.PayRiseTom = 30000 * 0.10 + 30000;

            Console.WriteLine($"\nEmployee {e3.EmployeeId}\n{e3.FirstName}{e3.LastName}\nWorks in the {e3.Department} department on a basic salary of EUR {e3.Salary:F}");

            Employee e4 = new Employee();
            e4.FirstName = "Mary";
            e4.LastName = "Smith";
            e4.EmployeeId = "emp145";
            e4.Salary = 35000.00 * 0.07 + 35000;
            e4.Department = "Finance";
            //e2.PayRiseTom = 35000 * 0.07 + 35000;

            Console.WriteLine($"\nEnployee {e4.EmployeeId}\n{e4.FirstName}{e4.LastName}\nWorks in the {e4.Department} department on a basic salary of EUR {e4.Salary:F}");

            Console.ReadLine();


        }



       }

    }

         







        

        

        //6 - Add a method PayRise which takes a % increase and changes the Salary

        //7 - Add some code to give both employees a pay rise.

    

