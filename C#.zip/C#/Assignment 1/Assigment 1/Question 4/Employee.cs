﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    class Employee
    {//1 - Create a class called Employee which contains properties for the First Name, Last Name, Employee ID, Salary, Department. 
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmployeeId { get; set; }
        public double Salary { get; set; }
        public string Department { get; set; }
        public double PayRiseTom { get; set; }
        public double PayRiseMary { get; set; }



        //2 - Add a constructor which takes all parameters
        public Employee(string firstName, string lastName, string employeeId, double salary, string department, double payrisetom, double payrisemary)
        {
            FirstName = firstName;
            LastName = lastName;
            EmployeeId = employeeId;
            Salary = salary;
            Department = department;
            PayRiseTom = payrisetom;
            PayRiseMary = payrisemary;
            //PyRise2 = payRise2;


        }

        public Employee()
        {

        }

        //3 - Add a PrintDetails method to which prints all data about the Employee object to the console. 
        public void PrintDetails()
        {
            Console.WriteLine($"{EmployeeId}/n{FirstName}{LastName}/n Works in the {Department} department on a basic salary of EUR {Salary}");

        }
        //5 - Add a method PayRise which takes a % increase and changes the Salary
        public static double CalculatePayRiseTom()
        {
            double salary = 30000;
            const double payrisetom = 0.10;

            return salary * payrisetom + 30000;
        }

        //5 - Add a method PayRise which takes a % increase and changes the Salary
        public static double CalculatePayRiseMary()
        {
            double salary = 30000;
            const double payrisemary = 0.07;

            return salary * payrisemary + 35000;
        }

    }

    }


