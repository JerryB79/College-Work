﻿//1 - Set Up
//2 - main string(void)
//3 - Display Instructions
//4 - Get Info(string)
//5 - Display results(string, double, double, double, double, double, double, double, double, double, double): void
//6 - Calculate Gross pay (double, double): double
//7 - Calculate Tax (double, double): double
//8 - Calculate PRSI (double, double): double
//9 - Calculate retirement paid (double, double): double
//10 - Calculate total deductions (double, double, double): double
//11 - Calculate take home pay (double, double, double, double): double

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_3
{
    class Program
    {
        static void Main(string[] args)
        {   //1 - Set Up
            const double COMMISSION_RATE = 0.07;
            const double INCOME_TAX = 0.25;
            const double PRSI = 0.04;
            const double RETIREMENT_RATE = 0.15;

            double sales, grossPay, incomeTax, prsi, pensionContribution, totalDeductions, netPay;
            string name;

            //3 - Display Instructions
            DisplayInstructions();
            //instructions = DisplayInstructions(instructions);

            //4 - Get Info(string)
            name = GetName();
            sales = GetSales();
            grossPay = CalculateGrossPay(sales, COMMISSION_RATE);
            incomeTax = CalculateTax(grossPay, INCOME_TAX);
            prsi = CalculatePrsi(grossPay, PRSI);
            pensionContribution = CalculatePension(grossPay, RETIREMENT_RATE);
            totalDeductions = CalculateTotalDeductions(incomeTax, prsi, pensionContribution);
            netPay = CalculateTakeHomePay(grossPay, totalDeductions);
            //name = GetInputValue("name");
            //sales = GetInputValue("sales");

            DisplayResults(name, sales, grossPay, incomeTax, prsi, pensionContribution, totalDeductions, netPay);
                                           
               
            //DisplayResults(name, sales, grossPay, incomeTax, prsi, pensionContribution, totalDeductions, netPay);

            Console.ReadKey();
        }
        //static void DisplayInstructions(string instructions);
        public static void DisplayInstructions()

        {
            Console.WriteLine("You will be asked to enter the name of an employee \nand his weekly sales. " +
            "Calculations will be performed to \ndetermine his take home pay.");

        }

        public static string GetName()

        {
            string inputValue;
            Console.Write("\nPlease enter an employee name: ");
            inputValue = Console.ReadLine();
            return inputValue;
        }


        public static double GetSales()
        {
            string inputValue;
            double sales;
            Console.Write("Please enter this employees weekly sales: ");
            inputValue = Console.ReadLine();
            sales = double.Parse(inputValue);
            return sales;

        }
        //6 - Calculate Gross pay (double, double): double
        public static double CalculateGrossPay(double sales, double COMMISSION_RATE)
        {

            return sales * COMMISSION_RATE;

        }

        //7 - Calculate Tax (double, double): double    
        public static double CalculateTax(double grossPay, double INCOME_TAX)
        {
            return grossPay * INCOME_TAX;

        }

        //8 - Calculate PRSI(double, double): double
        public static double CalculatePrsi(double grossPay, double PRSI)
        {
            return grossPay * PRSI;

        }
        //9 - Calculate retirement paid (double, double): double
        public static double CalculatePension(double grossPay, double RETIREMENT_RATE)
        {
            return grossPay * RETIREMENT_RATE;
        }
        //10 - Calculate total deductions (double, double, double): double
        public static double CalculateTotalDeductions(double incomeTax, double prsi, double pensionContribution)
        {
            return incomeTax + prsi + pensionContribution;

        }
        //11 - Calculate take home pay (double, double, double, double): double
        public static double CalculateTakeHomePay(double grossPay, double totalDeductions)
        {
            return grossPay - totalDeductions;

        }

            public static void DisplayResults(string name, double sales, double grossPay, double incomeTax, double prsi,
                                          double pensionContribution, double totalDeductions, double netPay)
            {
                Console.WriteLine("\n\t Weekly Payroll App");
                Console.WriteLine("\nEmployee Name: {0}", name);
                Console.WriteLine("\n\nThis week's Sales: \t\t{0,12:F}", sales);
                Console.WriteLine("Commission Rate: 7.00%");
                Console.WriteLine("\nGross Pay: \t\t\t{0,12:F}", grossPay);
                Console.WriteLine("Income Tax: \t\t (25%)\t{0,12:F}",incomeTax);
                Console.WriteLine("PRSI: \t\t\t (4%){0,15:F}",prsi);
                Console.WriteLine("Retirement Contribution: (15%)\t{0,12:F}", pensionContribution);
                Console.WriteLine("\nTotal Deductions\t\t{0,12:F}", totalDeductions);
                Console.WriteLine("\nTake Home Pay \t\t\t{0,12:F}", netPay);
                Console.ReadLine();
            }
        }
    }


