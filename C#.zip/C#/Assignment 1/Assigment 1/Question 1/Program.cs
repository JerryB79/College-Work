﻿//Write a program which asks the user for first name, surname and month of the year as a number.
//It should then output a message to the user using the name,
//surname and stating how many months it is until Xmas.
//1 - Ask user for First Name
//2 - Read First Name
//3 - Ask user for Surname
//4 - Read Surname
//5 - Ask user for month of the year as number
//6 - Read Month
//7 - Calculate Days to Christmas
//8 - Output Name, Surname, how many months to Chrstmas

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_1
{
    class Program
    {
        static void Main(string[] args)
        { 
            const double MONTHSINYEAR = 12;
            string firstname;
            string surname;
            string entrystring;
            double month;
            double daysTochristmas;

            //1 - Ask user for First Name
            Console.Write("Please enter your first name >> ");

            //2 - Read First Name
            firstname = Console.ReadLine();

            //3 - Ask user for surname
            Console.Write("Please enter your surname >> ");

            //4 - Read Surname
            surname = Console.ReadLine();

            //5 - Ask user for month of the year as number
            Console.Write("Please enter current month as a number, eg 1 for January >> ");
            //6 - Read month 
            //entrystring = Console.ReadLine();
           //month = Convert.ToDouble(entrystring);
            month = Convert.ToDouble(Console.ReadLine());

            //7 - Calculate Days to Christmas
            daysTochristmas = MONTHSINYEAR - month;

            //8 - Output Name, Surname, how many months to Chrstmas
            Console.Write("\n\nIt's exciting {0} that it is only {1} months to Xmas. \nI hope it's a good one in the {2} household.",
                firstname, daysTochristmas, surname);

            Console.ReadLine();



        }
    }
}
