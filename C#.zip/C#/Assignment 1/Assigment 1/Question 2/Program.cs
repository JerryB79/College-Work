﻿//Write a program which calculates a taxi fare based on distance, time, number of passengers and pieces of luggage.
//The rates are as follows.
//Price per km: €1.25
//Price per minute: €0.25
//Price for each passenger: €1
//Price for each piece of luggage €0.5
//1 - Setup
//2 - Ask user for KM travelled
//3 - Read KM 
//4 - Ask user for minutes taken
//5 - Read Minutes
//6 - Ask user for number of Passengers
//7 - Read Passengers
//8 - Ask user for pieces of luggage
//9 - Read luggage
//10 - Calculate cost pre Tax
//11 - Calculate Tax
//12 - Calculate total cost of Taxi
//13 - Output cost of Taxi pre tax, Tax & Total cost of Taxi

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //1 - Setup
            const decimal PRICE_PER_KM = 1.25m;
            const decimal PRICE_PER_MINUTE = 0.25m;
            const decimal PRICE_PER_PASSENGER = 1m;
            const decimal PRICE_PER_LUGGAGE = 0.5m;
            const decimal TAX_RATE = 0.135m;

            decimal km, time, passenger, luggage, totalPretax, tax, totalPosttax;

            //2 - Print - Taxi fare Calculator
            Console.Write("Taxi Fare Calculator");
            //2 - Ask user for KM travelled
            Console.Write("\n\nPlease enter km travelled >> ");
            //3 - Read KM 
            km = Convert.ToDecimal(Console.ReadLine());
            //4 - Ask user for minutes taken
            Console.Write("Please enter minutes taken >> ");
            //5 - Read Minutes
            time = Convert.ToDecimal(Console.ReadLine());
            //6 - Ask user for number of Passengers
            Console.Write("Please enter number of passengers >> ");
            //7 - Read Passengers
            passenger = Convert.ToDecimal(Console.ReadLine());
            //8 - Ask user for pieces of luggage
            Console.Write("Please enter pieces of luggage, 0 for none >> ");
            //9 - Read luggage
            luggage = Convert.ToDecimal(Console.ReadLine());
            //10 - Calculate cost pre Tax
            totalPretax = km * PRICE_PER_KM + time * PRICE_PER_MINUTE + passenger * PRICE_PER_PASSENGER + luggage * PRICE_PER_LUGGAGE;
            //11 - Calculate Tax
            tax = totalPretax * TAX_RATE;
            //12 - Calculate total cost of Taxi
            totalPosttax = totalPretax + tax;
            //13 - Output cost of Taxi pre tax, Tax & Total cost of Taxi
            Console.WriteLine("\nCost of Taxi \tEUR {0,7:F}", totalPretax);
            Console.WriteLine("Tax \t\tEUR {0,7:F}", tax);
            Console.WriteLine("Total Cost \tEUR {0,7:F}", totalPosttax);
            Console.ReadLine();
            }
        }

}
