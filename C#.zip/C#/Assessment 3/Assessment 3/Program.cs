﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BlackJack
{
    //Card Suit
    public enum Suit
    {
        Heart,
        Diamond,
        Spade,
        Club
    }
    //Card Values
    public enum Face
    {
        Ace,//1 or 11
        //Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,//10
        Queen,//10
        King,//10
    }



    //props
    public class Card
    {
        public Suit Suit { get; set; }
        public Face Face { get; set; }
        public int Value { get; set; }
    }
    //Card Deck Class
    public class Deck
    {
        private List<Card> cards;

        public Deck()
        {
            this.Initialize();
        }

        //Initialise Deck
        public void Initialize()
        {
            cards = new List<Card>();

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 13; j++)
                {
                    cards.Add(new Card() { Suit = (Suit)i, Face = (Face)j });

                    if (j <= 8)
                        cards[cards.Count - 1].Value = j + 1;
                    else
                        cards[cards.Count - 1].Value = 10;
                }
            }
        }

        //Deck Shuffle 
        public void Shuffle()
        {
            Random rng = new Random();
            int n = cards.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                Card card = cards[k];
                cards[k] = cards[n];
                cards[n] = card;
            }
        }

        //Draw a Card
        public Card DrawACard()
        {
            if (cards.Count <= 0)
            {
                this.Initialize();
                this.Shuffle();
            }

            Card cardToReturn = cards[cards.Count - 1];
            cards.RemoveAt(cards.Count - 1);
            return cardToReturn;
        }

        static Deck deck;
        static List<Card> userHand;
        static List<Card> dealerHand;

        static void Main(string[] args)
        {

            Console.Clear();
            Console.Title = "BlackJack";

            //New deck & shuffle
            deck = new Deck();
            deck.Shuffle();

            Console.WriteLine("BlackJack");



            Console.Clear();

            do
            {

                Console.Clear();

                //Gane Introduction

                Console.WriteLine("BlackJack");

                Console.WriteLine("Do you want to play BlackJack Y/N");

                //
                ConsoleKeyInfo play = Console.ReadKey(true);
                while (play.Key == ConsoleKey.Y && play.Key == ConsoleKey.N)
                    
                {
                    Console.WriteLine("Invalid input please choose an option Y or N: ");
                    play = Console.ReadKey(true);
                }

                Console.Clear();

                switch (play.Key)
                {
                    //Yes 
                    case ConsoleKey.Y:
                        DealHand();
                        Console.WriteLine("Press any key to continue");
                        Console.ReadKey(true);
                        continue;
                    //No
                    case ConsoleKey.N:
                        Console.WriteLine("Press any key to exit.");
                        Console.ReadKey(true);
                        Console.WriteLine("Maybe next time!!");
                        return;
                }

            } while (true);

        }

        //Deal hand
        static void DealHand()
        {
            //if (deck.GetAmountOfRemainingCrads() < 35)
            {
                deck.Initialize();
                deck.Shuffle();
            }

            //User Hand
            userHand = new List<Card>
            {
                deck.DrawACard(),
                deck.DrawACard()
            };

            foreach (Card card in userHand)
            {
                if (card.Face == Face.Ace)
                {
                    card.Value += 10;
                    break;
                }
            }

            //Dealer Hand
            dealerHand = new List<Card>
            {
                deck.DrawACard(),
                deck.DrawACard()
            };

            foreach (Card card in dealerHand)
            {

                if (card.Face == Face.Ace)
                {
                    card.Value += 10;
                    break;
                }
            }


                //Player Output
                Console.WriteLine("Card dealt is the {0} of {1}", userHand[0].Face, userHand[0].Suit);
                Console.WriteLine("Card dealt is the {0} of {1}", userHand[1].Face, userHand[1].Suit);
                Console.WriteLine("Your score is {0}", userHand[0].Value + userHand[1].Value);
                //Draw
                if (userHand[0].Value + userHand[1].Value == 21 && dealerHand[0].Value + dealerHand[1].Value == 17)
                {

                    Console.WriteLine("Its a tie");

                    return;
                }

                //Player Wins
                if (userHand[0].Value + userHand[1].Value == 21)
                {

                    Console.WriteLine("Player Wins");

                    return;
                }

                //Dealer Wins
                if (dealerHand[0].Value + dealerHand[1].Value == 17)
                {

                    Console.WriteLine("Dealer Wins");
                    return;

                }
                //Asking Player to Stick or Twist
                do
                {
                    Console.WriteLine("Would you like to (S)tick or (T)wist?");
                    ConsoleKeyInfo userOption = Console.ReadKey(true);
                    
                    switch (userOption.Key)
                    {//Twist Option
                        case ConsoleKey.T:
                            userHand.Add(deck.DrawACard());
                            Console.WriteLine("Twisted {0} of {1}", userHand[userHand.Count - 1].Face, userHand[userHand.Count - 1].Suit);
                            int totalCardsValue = 0;

                            foreach (Card card in userHand)
                            {
                                totalCardsValue += card.Value;
                            }

                            Console.WriteLine("Your score is {0}\n", totalCardsValue);
                            //Players Card Value Above 21
                            if (totalCardsValue > 21)
                            {

                                Console.WriteLine("Bust!");
                                Console.WriteLine("That was unfortunate!");

                                return;
                            }

                            else
                            {
                                continue;
                            }

                            //Dealer Output
                            case ConsoleKey.S:
                            Console.WriteLine("\nDealer plays");
                            Console.WriteLine("\nCard dealt is the {0} of {1}", dealerHand[0].Face, dealerHand[0].Suit);
                            Console.WriteLine("Card dealt is the {0} of {1}", dealerHand[1].Face, dealerHand[1].Suit);
                            Console.WriteLine("Dealer score is {0}", dealerHand[0].Value + dealerHand[1].Value);

                            int dealerCardsValue = 0;
                            foreach (Card card in dealerHand)
                            {
                                dealerCardsValue += card.Value;
                            }
                            int playerCardValue = 0;
                            foreach (Card card in userHand)
                            {
                                playerCardValue += card.Value;
                            }

                            //Deal again if under 17
                            while (dealerCardsValue < 17)
                            {
                                dealerHand.Add(deck.DrawACard());
                                dealerCardsValue = 0;

                                foreach (Card card in dealerHand)
                                {
                                    dealerCardsValue += card.Value;
                                }

                                Console.WriteLine("Card dealt is the {0} of {1}", dealerHand[dealerHand.Count - 1].Face, dealerHand[dealerHand.Count - 1].Suit);
                            }

                            dealerCardsValue = 0;
                            foreach (Card card in dealerHand)
                            {
                                dealerCardsValue += card.Value;
                            }

                            Console.WriteLine("Dealer score is {0}", dealerCardsValue, dealerHand[dealerHand.Count - 1].Face, dealerHand[dealerHand.Count - 1].Suit);
                            //When dealer value goes above 17
                            if (dealerCardsValue > 17)
                            {

                                Console.WriteLine("Player wins");

                                return;
                            }

                            else
                            {
                                //Dealer value greater than Player
                                if (dealerCardsValue > playerCardValue)
                                {

                                    Console.WriteLine("Dealer wins", dealerCardsValue, playerCardValue);
                                    Console.WriteLine("Hard luck Pal");

                                    return;
                                }
                                //Draw
                                else if (dealerCardsValue == playerCardValue)
                                {

                                    Console.WriteLine("The dealers value is {0} and your value is {1}, its a tie.", dealerCardsValue, playerCardValue);

                                    return;
                                }

                                else
                                {

                                    Console.WriteLine("Player wins");

                                    return;
                                }
                            }
                    }
                    Console.ReadLine();
                }
                while (true);
            }

        }
    }





